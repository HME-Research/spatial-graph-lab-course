# designs/ — your designs (JSON)

Your designs go here, one schema-v2 `.json` file each. They are yours to draw: a new toolkit has only this README (a zip or a commit cannot carry an empty folder). The starter's `first-design.json` is only an example; your AI does not copy it.

**Add a design**

1. Draw it in the app with your toolkit: open the app with `?toolkit=<your-toolkit-name>` and **Create project**, or give an open project your toolkit with **Project › Toolkit › Add a toolkit…** (or upload your toolkit zip).
2. **Project › Export project** gives a `.project.json` file. Ask your AI: "Take the design of the scenario *name* from this project file and give me it as `designs/<name>.json` for my toolkit, with a `metadata.name` and `metadata.description`."
3. Save it here as `designs/<name>.json` (in the browser route: in your zip, then upload the new zip). Run `npm run check:toolkit -- -t <your-toolkit-name>` again: it now runs every algorithm on your first design.

Its file name (without `.json`) is its design id; `metadata.name` and `metadata.description` are what **Open toolkit design…** shows under *Toolkit: <your toolkit name>*.

- Optional: name one design as `defaultDesign` in `toolkit.ts`; new projects then start from it and the checks run every algorithm on it. Keep it small and valid.
- Every node's `"function"` should be one of your Functions' ids; custom values go under `"custom"`.
- A design names an imported façade by its asset id; the `.3dm` file must then be in `assets/`.

Format: `lab/docs/STUDENT-API.md` › Designs and `lab/docs/CONTRACTS-V2.md` §1. This README is ignored by the app.
